var toy1 = new Object();
// console.log(toy1);

// toy1.color = "red";
Object.prototype.color = "red";

toy1.color = "blue";
Object.prototype.color = "yellow";
console.log(toy1);
console.log(toy1.color);

var toy2 = new Object();
console.log(toy2);
console.log(toy2.color);

