// let target = { a: 1, b: 2 };
// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// // let newSource = source;
// // let newSource = Object.assign({}, source);       // Shallow Copy
// // let newSource = Object.assign(target, source);
// let newSource = JSON.parse(JSON.stringify(source));     // Deep Copy

// console.log(source);
// console.log(newSource);

// // newSource.id = 100;
// newSource.address.city = "Mumbai";

// console.log("\n");
// console.log(source);
// console.log(newSource);

// ----------------------------------------- Object.create
// let source = { id: 1, name: "Manish", address: { city: "Pune" } };
// // Creates a new object, using an existing object as the prototype of the newly created object.

// // var t = new Test();
// // var t = Object.create(Test.prototype)

// var newSource = Object.create(source);
// var newSource = {};
// var newSource = new Object();
// var newSource = null;

// console.log(source);
// console.log(newSource);

// ---------------------------------------- Stop Object extension
// let source = { id: 1, name: "Manish" };

// // Object.freeze(source);
// Object.preventExtensions(source);

// if (Object.isExtensible(source))
//     source.city = "Pune";

// source.id = 100;

// console.log(source);
