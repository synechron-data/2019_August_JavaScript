// const Person = (function () {
//     function Person(name) {
//         this._name = name;
//     }

//     Object.defineProperty(Person.prototype, "Name", {
//         set: function(value){
//             this._name = value;
//         },
//         get: function(){
//             return this._name;
//         }
//     })

//     return Person;
// })();

// var p1 = new Person("Manish");
// console.log(p1.Name);
// p1.Name = "Ramakant";
// console.log(p1.Name);

// var p2 = new Person("Subodh");
// console.log(p2.Name);
// p2.Name = "Abhijeet";
// console.log(p2.Name);

// var employee = { id: 1, salary: 10000 };

var employee = {};

Object.defineProperty(employee, "salary", {
    value: 10000,
    writable: true,
    enumerable: true
})


employee.salary = 1000;
// console.log(employee.salary);

for (const key in employee) {
    console.log(employee[key]);
}