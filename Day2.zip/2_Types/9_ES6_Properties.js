class Person {
    constructor(name, age) {
        this._name = name;
        this._age = age;
    }

    get Age() {
        return this._age;
    }

    set Age(value) {
        this._age = value;
    }

    get Name() {
        return this._name;
    }

    set Name(name) {
        this._name = name;
    }
}


var p2 = new Person("Subodh", 40);
console.log(p2.Age);
p2.Age = 20;
console.log(p2.Age);
