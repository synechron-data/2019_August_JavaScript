
// var dev2;

// (function (d2) {
//     function Test() {
//         console.log("Hello from Test2.Test");
//     }

//     d2.Test = Test;
// })(dev2 = dev2 || {});

var dev1;

(function(d1){
    function Test(){
        console.log("Hello from Test2.Test");
    }

    d1.Test2 = Test;
})(dev1 = dev1 || {});