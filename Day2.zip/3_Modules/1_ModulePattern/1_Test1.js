var dev1;

(function(d1){
    function Test(){
        console.log("Hello from Test1.Test");
    }

    d1.Test = Test;
})(dev1 = dev1 || {});