var calculator = (function () {
    function add(x, y) {
        return x + y;
    }

    function sub(x, y) {
        return x - y;
    }

    function mul(x, y) {
        return x * y;
    }

    function div(x, y) {
        return x / y;
    }

    return {
        add, sub, mul
    };
})();

// console.log(calculator);

// var add = calculator.add;
// var sub = calculator.sub;

var { add, sub } = calculator;

console.log(add(2, 3));
console.log(sub(2, 3));