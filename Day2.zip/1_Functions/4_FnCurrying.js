// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// // greetings("Good Morning", "Abhijeet");
// // greetings("Good Morning", "Ramakant");
// // greetings("Good Morning", "Pravin");

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// console.log(Converter(' km', 1.6, 0, 20));
// console.log(Converter(' km', 1.6, 0, 40));
// console.log(Converter(' km', 1.6, 0, 50));
// console.log(Converter(' km', 1.6, 0, 60));

// function greetings(message) {
//     return function (name) {
//         console.log(`${message}, ${name}`);
//     }
// }

// var mGreet = greetings("Good Morning");

// mGreet("Abhijeet");
// mGreet("Ramakant");
// mGreet("Pravin");


// function Converter(toUnit, factor, offset) {
//     return function (input) {
//         return [((offset + input) * factor).toFixed(2), toUnit].join("");
//     }
// }

// var milesToKm = Converter(' km', 1.6, 0);
// console.log(milesToKm(20));
// console.log(milesToKm(30));

// var dollarToInr = Converter(' INR', 68, 0);
// console.log(dollarToInr(100));
// console.log(dollarToInr(1000));


function Converter(toUnit, factor, offset, input) {
    return [((offset + input) * factor).toFixed(2), toUnit].join("");
}

var milesToKm = Converter.bind(this, ' km', 1.6, 0);
console.log(milesToKm(20));
console.log(milesToKm(30));