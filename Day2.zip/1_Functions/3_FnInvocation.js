function Check() {
    console.log(arguments);
    console.log(this);
}

// Invoking
// Check();
// Check.call();
// Check.apply();

// Resetting Context
// var p1 = { id: 1 };

// function Check(x, y) {
//     console.log(arguments);
//     console.log(this);
//     console.log(`x = ${x}, y = ${y}`);
// }

// Check(1, 2);
// // var a = 10;
// // Check.call(a, 2, 3);
// Check.call(p1, 2, 3);
// Check.apply(p1, [2, 3]);


// var e1 = {
//     id: 1,
//     name: "Manish",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// var e2 = {
//     id: 2,
//     name: "Abhijeet",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// };

// e1.display();
// e2.display();

// const display = function () {
//     console.log(JSON.stringify(this));
// }

// var e1 = {
//     id: 1,
//     name: "Manish"
// };

// var e2 = {
//     id: 2,
//     name: "Abhijeet"
// };

// // display.call(e1);
// // display.call(e2);

// e1.display = display.bind(e1);
// e2.display = display.bind(e2);

// e1.display();
// e2.display();
// // -------------------------------------

// function Person() {
//     this.age = 20;
//     this.growOld = function () {
//         console.log(this);
//         this.age += 1;
//     }
// }

// var p1 = new Person();
// p1.growOld();
// p1.growOld();
// p1.growOld();
// console.log(p1.age);

// -------------------------------------

function Person() {
    var self = this;
    self.age = 20;
    self.growOld = function () {
        console.log(this);
        self.age += 1;
    }
}

var p1 = new Person();

// setInterval(p1.growOld.bind(p1), 1000);
setInterval(p1.growOld, 1000);

setInterval(function () {
    console.log(p1.age);
}, 1000);