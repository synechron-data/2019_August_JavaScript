// function Reverse(strOrarr) {
//     if (typeof strOrarr === "string")
//         return strOrarr.split("").reverse();
//     else if (Object.prototype.toString.call(strOrarr) === "[object Array]")
//         return strOrarr.slice().reverse();
//     else
//         throw Error("Invalid Parameter type...");
// }

// function Reverse(strOrarr) {
//     if (typeof strOrarr === "string")
//         return strOrarr.split("").reverse();
//     else if (Array.isArray(strOrarr))
//         return [...strOrarr].reverse();
//     else
//         throw Error("Invalid Parameter type...");
// }

// console.log(Reverse("Manish"));
// console.log(Reverse(["PQR", "XYZ", "ABC"]));
// console.log(Reverse([10, 20, 30]));
// console.log(Reverse(10));

console.log(Object.prototype.toString.call(["PQR", "XYZ", "ABC"]))
console.log(Object.prototype.toString())
