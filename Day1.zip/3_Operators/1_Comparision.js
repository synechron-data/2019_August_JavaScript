'use strict'

// var a = 45;
// var b = "45";

// var r1 = a == b;    // Abstract Equality
// console.log(r1);

// var r2 = a === b;    // Strict Equality
// console.log(r2);


// var a = "abc";
// // var b = "abc";
// var b = new String("abc");

// console.log(typeof a);
// console.log(typeof b);

// console.log(String.prototype)

// var r1 = a == b;    // Abstract Equality
// console.log(r1);

// var r2 = a === b;    // Strict Equality
// console.log(r2);

// var s1 = '2+2';
// var s2 = String('2+2');
// var s3 = new String('2+2');

// console.log(eval(s1))
// console.log(eval(s2))
// console.log(eval(s3))

// const s1 = "BLUE";
// const s2 = "BLUE";

// const s1 = String("BLUE");
// const s2 = String("BLUE");

// const s1 = new String("BLUE");
// const s2 = new String("BLUE");

// var o1 = new Object();
// // var o2 = new Object();
// var o2 = o1;

// console.log(o1 == o2)


const s1 = Symbol("BLUE");
const s2 = Symbol("BLUE");
console.log(s1 == s2);
console.log(s1 === s2);