// document.getElementById("b1").addEventListener("click", function(){
// })

// $("#b1").click(function(){
// })

// var i = 0;
// setInterval(function () {
//     console.log(++i);
// }, 2000);

// function getString() {
//     const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];
//     var str = strArr[Math.floor(Math.random() * strArr.length)];
//     return str;
// }

// setInterval(function () {
//     var s = getString();
//     console.log(s);
// }, 2000);


function getString(cb) {
    const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];
    setInterval(function () {
        var str = strArr[Math.floor(Math.random() * strArr.length)];
        cb(str);
    }, 2000);
}

// function rData(s){
//     console.log(s);
// }

// getString(rData);

getString(function(s){
    console.log(s);
});

// var cb = function(s){
//     console.log(s);
// };

// cb("abc");