// // Function Declaration Syntax

// function hello1() {
//     console.log("Welcome to JS World!");
// }

// hello1();

// // Function Expression Syntax

// const hello2 = function () {
//     console.log("Welcome to JS World!");
// }

// hello2();

// // Function Constructor Syntax

// const hello3 = new Function('console.log("Welcome to JS World!");');
// hello3();

// --------------------------------------
const i = 10;
console.log(i);
console.log(typeof i);

const hello = function () {
    console.log("Welcome to JS World!");
}

console.log(hello);
console.log(typeof hello);

