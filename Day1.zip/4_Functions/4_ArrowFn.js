// function Add1(x, y) {
//     return x + y;
// }

// const Add2 = function (x, y) {
//     return x + y;
// }

// const Add3 = (x, y) => {
//     return x + y;
// }

// const Add4 = (x, y) => x + y;

// console.log(Add1(2, 3));
// console.log(Add2(2, 3));
// console.log(Add3(2, 3));
// console.log(Add4(2, 3));

// ----------------------------------------- With Arrow
// function getString(cb) {
//     const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];
//     setInterval(function () {
//         var str = strArr[Math.floor(Math.random() * strArr.length)];
//         cb(str);
//     }, 2000);
// }

// getString((s) => {
//     console.log(s);
// });

var employeeArr = [
    { id: 1, name: "Manish" },
    { id: 2, name: "Abhijeet" },
    { id: 3, name: "Pravin" }
];

// var result;

// for (let i = 0; i < employeeArr.length; i++) {
//     if (employeeArr[i].id == 4) {
//         result = employeeArr[i];
//         break;
//     }
// }

// function searchLogic(item){
//     return item.id == 3;
// }

// var result = employeeArr.find(searchLogic);

// var result = employeeArr.find(function (item){
//     return item.id == 3;
// });

// var result = employeeArr.find((item) => {
//     return item.id == 3;
// });

var result = employeeArr.find(item => item.id == 3);

if (result)
    console.log(result)
else
    console.log("Employee not found..");