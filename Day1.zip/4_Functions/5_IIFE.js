// Immediatly Invoked Function Expression (IIFE)

// function hello(name) {
//     console.log("Hello,", name);
// }

// hello("Synechron");

// (function (name) {
//     console.log("Hello,", name);
// })("Synechron");

((name) => {
    console.log("Hello,", name);
})("Synechron");
