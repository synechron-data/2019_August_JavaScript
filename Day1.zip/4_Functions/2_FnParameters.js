// function hello(name) {
//     console.log("Welcome,", name);
// }

// hello("Synechron");
// hello(23);
// hello(true);

// hello();
// hello("Manish", "Pune", 411021);

// -------------------------------  Handling Less Paramaters
// function Add(x, y) {
//     x = x || 0;
//     y = y || 0;

//     if (((typeof x) == "number") && (typeof y) == "number")
//         return x + y;

//     throw Error("Invalid Parameters...");

// }

// ES 2015 - Default Parameters
// function Add(x = 0, y = 0) {
//     if (((typeof x) == "number") && (typeof y) == "number")
//         return x + y;

//     throw Error("Invalid Parameters...");
// }

// console.log(Add(2, 3));
// console.log(Add(2));
// console.log(Add());

// console.log(Add(2, "ABC"));
// console.log(Add(true, "ABC"));

// -------------------------------  Handling Extra Paramaters
// function hello(name) {
//     console.log("Welcome,", name);
//     console.log(arguments);
// }

// hello("Abhijeet");
// hello("Abhijeet", "Gole");
// hello("Abhijeet", "Gole", "Pune");

// Rest Parameters
// function hello(name, ...args) {
//     console.log("Welcome,", name);
//     console.log(args);
// }

// hello("Abhijeet");
// hello("Abhijeet", "Gole");
// hello("Abhijeet", "Gole", "Pune");

function average(...numbers) {
    console.log(numbers);

    var sum = 0;
    for (let i = 0; i < numbers.length; i++) {
        sum += numbers[i];
    }

    if (numbers.length > 0)
        return sum / numbers.length;
    else
        return sum;
}

// console.log(average());
// console.log(average(1));
// console.log(average(1, 2));
// console.log(average(1, 2, 3, 4, 5));
// console.log(average(1, 2, 3, 4, 5, 6, 7, 8, 9));

// var arr = [1, 2, 3, 4, 5, 6, 7, 8, 9];
// console.log(average(...arr));       //Spread Operator

// var arr1 = [1, 2, 3, 4, 5, 6];
// var arr2 = arr1;
// var arr2 = [...arr1];

// console.log(arr1);
// console.log(arr2);

// console.log(arr1 === arr2);

var arr = [10, 20, 30, 40, 50, 60];

// Array Destructuring

// var x = arr[0];
// var y = arr[1];

// [x, , y] = arr;

// [x, ...y] = arr;

// console.log(`x = ${x}, y = ${y}`);
// console.log(typeof x)
// console.log(typeof y)

[x, , y] = arr;
console.log("Before, x = " + x + ", y = " + y);
// ES2015 - Template Literal
// console.log(`Before, x = ${x}, y = ${y}`);

[x, y] = [y, x];

console.log(`After, x = ${x}, y = ${y}`);
