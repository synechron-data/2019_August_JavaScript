'use strict'

var language;
console.log("Langugage is: ", language);
console.log("Type of Langugage is: ", typeof language);

language = null;
console.log("Langugage is: ", language);
console.log("Type of Langugage is: ", typeof language);

// language = "JavaScript";
// language = 'JavaScript';
language = `Java


            Script`;
console.log("Langugage is: ", language);
console.log("Type of Langugage is: ", typeof language);

// language = 10;
language = 10.5;
console.log("Langugage is: ", language);
console.log("Type of Langugage is: ", typeof language);

language = true;
console.log("Langugage is: ", language);
console.log("Type of Langugage is: ", typeof language);

language = Symbol("abc");
console.log("Langugage is: ", language);
console.log("Type of Langugage is: ", typeof language);