'use strict'
const env = "production";
console.log(env);

// env = "development";
// console.log(env);

// if (true) {
//     // env = "development";
//     const env = "development";
//     console.log(env);
// }

const obj = { id: 1, name: "Manish" };
console.log(obj);

// obj.id = 100;
obj = {};
console.log(obj);
