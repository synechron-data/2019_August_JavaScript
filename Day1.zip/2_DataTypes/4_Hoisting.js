'use strict'

// // i = 10;
// // console.log(i);

// function Test() {
//     i = 10;
//     console.log(i);
// }

// Test();

// var i;


// i = 10;
// console.log(i);
// var i = 10;

// i = 10;
// console.log(i);
// let i;