'use strict'
// a = 20;
// console.log(a);

// function Check(){
//     a = 10;
//     console.log("Inside Fn, a is", a);
// }

// Check();
// console.log("Outside Fn, a is", a);

// var i = "Manish";
// console.log("Outside, i is", i);

// function Test() {
//     var i = "Abhijeet";
//     console.log("Inside, i is", i);
// }

// Test();

// var a = 10;
// var a = "abc";
// console.log(a);

// var i = "Manish";
// console.log("Before, i is", i);

// // for (var i = 0; i < 5; i++) {
// //     console.log("Inside, i is", i);
// // }

// // for (var _i = 0; _i < 5; _i++) {
// //     console.log("Inside, i is", _i);
// // }

// console.log("After, i is", i);


var i = "Manish";
console.log("Before, i is", i);

// IIFE
(function () {
    for (var i = 0; i < 5; i++) {
        console.log("Inside, i is", i);
    }
})();

console.log("After, i is", i);
